import asyncio
import aiohttp

class DiscordWebhook:

    async def post_message(self, webhook_url, params):
        """Function to send a message to Discord using a webhook"""
        try:
            session = aiohttp.ClientSession()
            await session.post(webhook_url, json=params)
            session.close()
        except aiohttp.client_exceptions.ClientConnectorError: #If internet down, don't crash
            session.close()